"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { services } from "@/lib/data";

export default function Services() {
  return (
    <section id="services" className="bg-gray-light py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-16">
          <span className="font-mono text-xs uppercase tracking-widest text-blue">
            What we deliver
          </span>
          <h2 className="font-display text-4xl sm:text-5xl mt-4 text-navy leading-[1.05]">
            Six disciplines, engineered as one system.
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: (i % 3) * 0.08 }}
              className="group rounded-2xl bg-white p-7 border border-navy/5 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <div className="flex items-start justify-between">
                <span className="font-mono text-xs text-slate">{s.tag}</span>
                <span className="h-2 w-2 rounded-full bg-emerald opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="font-heading text-xl mt-4 text-navy">{s.title}</h3>
              <p className="mt-2 text-sm text-slate leading-relaxed">{s.summary}</p>
              <ul className="mt-5 space-y-2">
                {s.items.map((it) => (
                  <li key={it} className="flex items-center gap-2 text-sm text-navy/70">
                    <Check size={14} className="text-blue shrink-0" />
                    {it}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
