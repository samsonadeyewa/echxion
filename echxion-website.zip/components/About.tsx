"use client";

import { motion } from "framer-motion";
import { Target, Eye, Compass } from "lucide-react";

const pillars = [
  {
    icon: Target,
    title: "Our mission",
    body: "To engineer intelligent, sustainable systems that make homes, businesses, and industries measurably more efficient, secure, and future-ready.",
  },
  {
    icon: Eye,
    title: "Our vision",
    body: "To be the reference point for intelligent infrastructure across Africa — where automation, energy, and engineering are designed as one system.",
  },
  {
    icon: Compass,
    title: "Our values",
    body: "Precision engineering, transparent delivery, and technology chosen for outcomes — never installed for its own sake.",
  },
];

export default function About() {
  return (
    <section id="about" className="bg-white py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-blue">
              About ECHXION
            </span>
            <h2 className="font-display text-4xl sm:text-5xl mt-4 leading-[1.05] text-navy">
              Engineering firm.
              <br />
              Technology company.
              <br />
              One integrated team.
            </h2>
            <p className="mt-6 text-slate text-lg leading-relaxed max-w-lg">
              ECHXION LTD is a Nigerian engineering and technology company
              delivering intelligent solutions across smart home automation,
              AI, IoT, electrical engineering, and renewable energy. We design,
              install, integrate, and maintain systems that improve efficiency,
              increase security, optimize energy consumption, and create
              sustainable environments.
            </p>
            <p className="mt-4 text-slate text-lg leading-relaxed max-w-lg">
              Clients choose us because we don&apos;t sell fixed packages —
              every system is engineered against the site, the budget, and the
              outcome that actually matters to the people using it.
            </p>
          </div>

          <div className="space-y-6">
            {pillars.map((p, i) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex gap-5 rounded-2xl border border-navy/10 p-6 hover:border-blue/40 transition-colors"
              >
                <div className="shrink-0 h-11 w-11 rounded-full bg-navy flex items-center justify-center">
                  <p.icon size={18} className="text-emerald" />
                </div>
                <div>
                  <h3 className="font-heading text-lg text-navy">{p.title}</h3>
                  <p className="mt-1.5 text-slate text-sm leading-relaxed">{p.body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
