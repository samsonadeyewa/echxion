"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { blogPosts } from "@/lib/data";

export default function Blog() {
  return (
    <section id="blog" className="bg-gray-light py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-14">
          <span className="font-mono text-xs uppercase tracking-widest text-blue">
            Engineering Insights
          </span>
          <h2 className="font-display text-4xl sm:text-5xl mt-4 text-navy leading-[1.05]">
            Field notes from live projects.
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post, i) => (
            <motion.a
              href="#"
              key={post.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: (i % 3) * 0.08 }}
              className="group rounded-2xl bg-white p-6 border border-navy/5 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col"
            >
              <span className="font-mono text-[10px] uppercase tracking-wide text-emerald">
                {post.category}
              </span>
              <h3 className="font-heading text-lg mt-3 text-navy leading-snug">
                {post.title}
              </h3>
              <p className="mt-2 text-sm text-slate leading-relaxed flex-1">{post.excerpt}</p>
              <div className="mt-5 flex items-center justify-between">
                <span className="font-mono text-[11px] text-slate">{post.readTime}</span>
                <ArrowUpRight
                  size={16}
                  className="text-blue group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
                />
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
