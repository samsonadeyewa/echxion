"use client";

import { motion } from "framer-motion";
import {
  Stethoscope,
  Building2,
  Hotel,
  Factory,
  GraduationCap,
  Landmark,
  ShoppingBag,
  Home,
} from "lucide-react";
import { industries } from "@/lib/data";

const icons = [Stethoscope, Building2, Hotel, Factory, GraduationCap, Landmark, ShoppingBag, Home];

export default function Industries() {
  return (
    <section id="industries" className="bg-gray-light py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-14">
          <span className="font-mono text-xs uppercase tracking-widest text-blue">
            Industries served
          </span>
          <h2 className="font-display text-4xl sm:text-5xl mt-4 text-navy leading-[1.05]">
            Built for how each sector actually operates.
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {industries.map((ind, i) => {
            const Icon = icons[i];
            return (
              <motion.div
                key={ind}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="rounded-2xl bg-white border border-navy/5 p-6 text-center hover:border-emerald/50 transition-colors"
              >
                <Icon size={22} className="mx-auto text-blue" />
                <p className="mt-3 font-heading text-sm text-navy">{ind}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
