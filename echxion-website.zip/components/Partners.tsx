import { partners } from "@/lib/data";

export default function Partners() {
  const loop = [...partners, ...partners];

  return (
    <section className="bg-white py-16 border-y border-navy/5 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 mb-8">
        <span className="font-mono text-xs uppercase tracking-widest text-slate">
          Technology partners &amp; platforms
        </span>
      </div>
      <div className="relative">
        <div className="flex w-max animate-marquee gap-16">
          {loop.map((p, i) => (
            <span
              key={i}
              className="font-heading text-xl sm:text-2xl text-navy/25 whitespace-nowrap select-none"
            >
              {p}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
