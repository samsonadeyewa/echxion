"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, ChevronRight } from "lucide-react";

const nodes = [
  { x: 60, y: 90 },
  { x: 210, y: 40 },
  { x: 340, y: 120 },
  { x: 470, y: 60 },
  { x: 560, y: 170 },
  { x: 400, y: 230 },
  { x: 240, y: 210 },
  { x: 120, y: 260 },
];

const paths = [
  "M60,90 L210,40",
  "M210,40 L340,120",
  "M340,120 L470,60",
  "M470,60 L560,170",
  "M340,120 L400,230",
  "M400,230 L240,210",
  "M240,210 L120,260",
  "M240,210 L60,90",
  "M120,260 L340,120",
];

export default function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-screen bg-navy-deep overflow-hidden flex items-center pt-28 pb-16"
    >
      <div className="absolute inset-0 bg-schematic opacity-60" />
      <div className="absolute inset-0 bg-gradient-to-b from-navy-deep via-navy-deep/95 to-navy" />
      <div
        className="absolute -top-40 right-[-10%] h-[560px] w-[560px] rounded-full opacity-20 blur-3xl"
        style={{ background: "radial-gradient(circle, #007BFF 0%, transparent 70%)" }}
      />

      <div className="relative mx-auto max-w-7xl w-full px-6 lg:px-10 grid lg:grid-cols-[1.1fr_0.9fr] gap-14 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 mb-8"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-emerald" />
            <span className="font-heading text-xs tracking-wide text-white/70 uppercase">
              Intelligent Infrastructure &amp; Sustainable Energy
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-white text-[13vw] leading-[0.98] sm:text-6xl lg:text-[4.4rem] tracking-tight"
          >
            Engineering
            <br />
            smarter futures.
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue to-emerald">
              Powering intelligent living.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.22 }}
            className="mt-8 max-w-xl text-white/60 text-lg leading-relaxed"
          >
            ECHXION LTD designs intelligent engineering solutions that combine
            AI, automation, electrical systems, and renewable energy to
            transform homes, businesses, and industries.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.34 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full bg-emerald px-7 py-3.5 font-heading text-sm text-navy-deep hover:scale-[1.03] transition-transform"
            >
              Request Consultation
              <ArrowUpRight size={16} />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-1.5 rounded-full border border-white/25 px-7 py-3.5 font-heading text-sm text-white hover:border-white/60 transition-colors"
            >
              Explore Services
              <ChevronRight size={16} />
            </a>
          </motion.div>
        </div>

        {/* Signature element: animated systems schematic */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="relative hidden lg:block"
        >
          <svg viewBox="0 0 620 320" className="w-full h-auto">
            {paths.map((d, i) => (
              <motion.path
                key={d}
                d={d}
                fill="none"
                stroke="#007BFF"
                strokeWidth="1.5"
                strokeOpacity="0.5"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.1, delay: 0.6 + i * 0.12, ease: "easeInOut" }}
              />
            ))}
            {nodes.map((n, i) => (
              <g key={i}>
                <motion.circle
                  cx={n.x}
                  cy={n.y}
                  r={5}
                  fill="#1DB954"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 1.2 + i * 0.08, duration: 0.4 }}
                />
                <circle cx={n.x} cy={n.y} r={5} fill="none" stroke="#1DB954" strokeWidth="1" className="node-pulse" />
              </g>
            ))}
          </svg>
          <div className="mt-4 flex items-center justify-between font-mono text-[11px] text-white/40 tracking-wide">
            <span>SYS.NET // GRID-08</span>
            <span>LIVE TELEMETRY</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
