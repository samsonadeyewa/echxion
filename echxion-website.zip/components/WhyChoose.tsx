"use client";

import { motion } from "framer-motion";
import {
  ShieldCheck,
  Lightbulb,
  Leaf,
  Clock,
  BookCheck,
  Truck,
  Users,
} from "lucide-react";
import { whyChoose } from "@/lib/data";

const icons = [ShieldCheck, Lightbulb, Leaf, Clock, BookCheck, Truck, Users];

export default function WhyChoose() {
  return (
    <section className="bg-navy-deep py-28 relative overflow-hidden">
      <div className="absolute inset-0 bg-schematic opacity-30" />
      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-16">
          <span className="font-mono text-xs uppercase tracking-widest text-emerald">
            Why ECHXION
          </span>
          <h2 className="font-display text-4xl sm:text-5xl mt-4 text-white leading-[1.05]">
            Reliability, engineered in.
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden">
          {whyChoose.map((w, i) => {
            const Icon = icons[i % icons.length];
            return (
              <motion.div
                key={w.title}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="bg-navy-deep p-7 hover:bg-navy transition-colors"
              >
                <Icon size={20} className="text-blue" />
                <h3 className="font-heading text-base mt-4 text-white">{w.title}</h3>
                <p className="mt-1.5 text-sm text-white/50 leading-relaxed">{w.body}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
