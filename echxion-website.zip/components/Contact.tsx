"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, MessageCircle, Send } from "lucide-react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="bg-navy-deep py-28 relative overflow-hidden">
      <div className="absolute inset-0 bg-schematic opacity-30" />
      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-16">
          <span className="font-mono text-xs uppercase tracking-widest text-emerald">
            Get in touch
          </span>
          <h2 className="font-display text-4xl sm:text-5xl mt-4 text-white leading-[1.05]">
            Tell us what you&apos;re building.
          </h2>
          <p className="mt-5 text-white/60 text-lg">
            A technical advisor responds within one business day with next steps.
          </p>
        </div>

        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-12">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="h-11 w-11 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                <Phone size={17} className="text-emerald" />
              </div>
              <div>
                <p className="font-heading text-white">+234 800 000 0000</p>
                <p className="text-sm text-white/45">Mon – Sat, 8am – 6pm WAT</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="h-11 w-11 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                <Mail size={17} className="text-emerald" />
              </div>
              <div>
                <p className="font-heading text-white">hello@echxion.com</p>
                <p className="text-sm text-white/45">General &amp; project inquiries</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="h-11 w-11 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                <MapPin size={17} className="text-emerald" />
              </div>
              <div>
                <p className="font-heading text-white">Victoria Island, Lagos, Nigeria</p>
                <p className="text-sm text-white/45">Site visits by appointment</p>
              </div>
            </div>

            <a
              href="https://wa.me/2348000000000"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-emerald/15 border border-emerald/40 px-5 py-3 font-heading text-sm text-emerald hover:bg-emerald/25 transition-colors"
            >
              <MessageCircle size={16} />
              Chat on WhatsApp
            </a>

            <div className="rounded-2xl overflow-hidden border border-white/10 h-56 mt-4">
              <iframe
                title="ECHXION LTD location"
                className="w-full h-full grayscale invert-[0.9] contrast-[1.1]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src="https://www.google.com/maps?q=Victoria+Island,+Lagos,+Nigeria&output=embed"
              />
            </div>
          </div>

          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-2xl bg-white p-8"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16">
                <div className="h-12 w-12 rounded-full bg-emerald/10 flex items-center justify-center mb-4">
                  <Send size={20} className="text-emerald" />
                </div>
                <h3 className="font-heading text-xl text-navy">Request sent</h3>
                <p className="mt-2 text-slate text-sm max-w-xs">
                  Thank you — a technical advisor will reach out within one business day.
                </p>
              </div>
            ) : (
              <>
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="font-mono text-[11px] uppercase text-slate">Full name</label>
                    <input
                      required
                      type="text"
                      className="mt-1.5 w-full rounded-lg border border-navy/15 px-4 py-3 text-sm text-navy outline-none focus:border-blue"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="font-mono text-[11px] uppercase text-slate">Phone</label>
                    <input
                      required
                      type="tel"
                      className="mt-1.5 w-full rounded-lg border border-navy/15 px-4 py-3 text-sm text-navy outline-none focus:border-blue"
                      placeholder="+234"
                    />
                  </div>
                </div>
                <div className="mt-5">
                  <label className="font-mono text-[11px] uppercase text-slate">Email</label>
                  <input
                    required
                    type="email"
                    className="mt-1.5 w-full rounded-lg border border-navy/15 px-4 py-3 text-sm text-navy outline-none focus:border-blue"
                    placeholder="you@company.com"
                  />
                </div>
                <div className="mt-5">
                  <label className="font-mono text-[11px] uppercase text-slate">Service of interest</label>
                  <select className="mt-1.5 w-full rounded-lg border border-navy/15 px-4 py-3 text-sm text-navy outline-none focus:border-blue bg-white">
                    <option>Smart Home Automation</option>
                    <option>Artificial Intelligence</option>
                    <option>Electrical Engineering</option>
                    <option>Solar &amp; Renewable Energy</option>
                    <option>IoT Solutions</option>
                    <option>Engineering Consultancy</option>
                  </select>
                </div>
                <div className="mt-5">
                  <label className="font-mono text-[11px] uppercase text-slate">Project details</label>
                  <textarea
                    required
                    rows={4}
                    className="mt-1.5 w-full rounded-lg border border-navy/15 px-4 py-3 text-sm text-navy outline-none focus:border-blue resize-none"
                    placeholder="Tell us about your site and goals"
                  />
                </div>
                <button
                  type="submit"
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-navy px-7 py-3.5 font-heading text-sm text-white hover:bg-navy-deep transition-colors"
                >
                  Send request
                  <Send size={15} />
                </button>
              </>
            )}
          </motion.form>
        </div>
      </div>
    </section>
  );
}
