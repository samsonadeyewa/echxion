"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, MapPin } from "lucide-react";
import { projects, projectCategories, ProjectCategory } from "@/lib/data";

const gradients: Record<ProjectCategory, string> = {
  Residential: "from-blue/70 to-emerald/40",
  Commercial: "from-navy to-blue/60",
  Industrial: "from-navy-deep to-navy",
  Solar: "from-emerald/70 to-blue/40",
  Automation: "from-blue/60 to-navy",
  Electrical: "from-navy to-emerald/30",
};

export default function Projects() {
  const [active, setActive] = useState<ProjectCategory | "All">("All");
  const [openId, setOpenId] = useState<string | null>(null);

  const filtered =
    active === "All" ? projects : projects.filter((p) => p.category === active);

  return (
    <section id="projects" className="bg-white py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-12">
          <div className="max-w-xl">
            <span className="font-mono text-xs uppercase tracking-widest text-blue">
              Featured Projects
            </span>
            <h2 className="font-display text-4xl sm:text-5xl mt-4 text-navy leading-[1.05]">
              Proof, not promises.
            </h2>
          </div>

          <div className="flex flex-wrap gap-2">
            {(["All", ...projectCategories] as const).map((c) => (
              <button
                key={c}
                onClick={() => setActive(c)}
                className={`rounded-full px-4 py-2 font-heading text-xs transition-colors ${
                  active === c
                    ? "bg-navy text-white"
                    : "bg-gray-light text-slate hover:text-navy"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filtered.map((p) => (
              <motion.div
                layout
                key={p.id}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.3 }}
                className="rounded-2xl overflow-hidden border border-navy/10 group"
              >
                <button
                  onClick={() => setOpenId(openId === p.id ? null : p.id)}
                  className="w-full text-left"
                >
                  <div
                    className={`h-44 bg-gradient-to-br ${gradients[p.category]} relative flex items-end p-5`}
                  >
                    <span className="font-mono text-[10px] uppercase tracking-wide text-white/80 bg-black/20 rounded-full px-2.5 py-1">
                      {p.category}
                    </span>
                    <ArrowUpRight
                      size={18}
                      className="absolute top-4 right-4 text-white/80 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
                    />
                  </div>
                  <div className="p-5">
                    <h3 className="font-heading text-lg text-navy">{p.title}</h3>
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-slate">
                      <MapPin size={12} /> {p.location}
                    </p>
                  </div>
                </button>

                <AnimatePresence>
                  {openId === p.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden border-t border-navy/10"
                    >
                      <div className="p-5 space-y-3 bg-gray-light">
                        <div>
                          <p className="font-mono text-[10px] uppercase text-slate">Client</p>
                          <p className="text-sm text-navy">{p.client}</p>
                        </div>
                        <div>
                          <p className="font-mono text-[10px] uppercase text-slate">Services</p>
                          <p className="text-sm text-navy">{p.services.join(" · ")}</p>
                        </div>
                        <div>
                          <p className="font-mono text-[10px] uppercase text-slate">Challenge</p>
                          <p className="text-sm text-navy/80 leading-relaxed">{p.challenge}</p>
                        </div>
                        <div>
                          <p className="font-mono text-[10px] uppercase text-emerald">Result</p>
                          <p className="text-sm text-navy leading-relaxed">{p.result}</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
