"use client";

import { useState } from "react";
import { Send } from "lucide-react";

function InstagramIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
function LinkedinIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.7c0-1.36-.02-3.1-1.9-3.1-1.9 0-2.2 1.48-2.2 3v5.8h-4V9Z" />
    </svg>
  );
}
function FacebookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M13.5 21v-8h2.7l.4-3.1h-3.1V8c0-.9.25-1.5 1.55-1.5H16.7V3.7C16.4 3.66 15.4 3.57 14.24 3.57c-2.4 0-4.05 1.47-4.05 4.16V9.9H7.5V13h2.7v8h3.3Z" />
    </svg>
  );
}
function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M4 3h3.6l4.1 5.6L16.4 3H20l-6.2 7.9L20.4 21H16.8l-4.5-6.1L7.4 21H4l6.6-8.4L4 3Z" />
    </svg>
  );
}

const columns = [
  {
    title: "Services",
    links: [
      "Smart Home Automation",
      "Artificial Intelligence",
      "Electrical Engineering",
      "Solar & Renewable Energy",
      "IoT Solutions",
      "Engineering Consultancy",
    ],
  },
  {
    title: "Company",
    links: ["About Us", "Featured Projects", "Industries Served", "Careers", "Contact"],
  },
  {
    title: "Resources",
    links: ["Engineering Insights", "FAQ", "Case Studies", "Support"],
  },
];

export default function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <footer className="bg-navy-deep pt-20 pb-8">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid lg:grid-cols-[1.2fr_1fr_1fr_1fr] gap-12 pb-14 border-b border-white/10">
          <div>
            <span className="font-display text-2xl text-white">ECHXION</span>
            <p className="mt-4 text-sm text-white/50 max-w-xs leading-relaxed">
              Intelligent infrastructure and sustainable energy solutions for
              homes, businesses, industries, and government institutions
              across Nigeria and beyond.
            </p>
            <div className="mt-6">
              <p className="font-mono text-[11px] uppercase text-white/40 mb-2">Newsletter</p>
              {sent ? (
                <p className="text-sm text-emerald">Subscribed — thank you.</p>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSent(true);
                  }}
                  className="flex gap-2"
                >
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    className="min-w-0 flex-1 rounded-full border border-white/15 bg-transparent px-4 py-2.5 text-sm text-white outline-none focus:border-emerald placeholder:text-white/30"
                  />
                  <button
                    type="submit"
                    aria-label="Subscribe"
                    className="h-10 w-10 shrink-0 rounded-full bg-emerald flex items-center justify-center"
                  >
                    <Send size={15} className="text-navy-deep" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <p className="font-mono text-[11px] uppercase tracking-wide text-white/40 mb-4">
                {col.title}
              </p>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} ECHXION LTD. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" aria-label="Instagram" className="text-white/50 hover:text-emerald transition-colors">
              <InstagramIcon width={17} height={17} />
            </a>
            <a href="#" aria-label="LinkedIn" className="text-white/50 hover:text-emerald transition-colors">
              <LinkedinIcon width={17} height={17} />
            </a>
            <a href="#" aria-label="Facebook" className="text-white/50 hover:text-emerald transition-colors">
              <FacebookIcon width={17} height={17} />
            </a>
            <a href="#" aria-label="X" className="text-white/50 hover:text-emerald transition-colors">
              <XIcon width={17} height={17} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
