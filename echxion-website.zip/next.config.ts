import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  images: {
    unoptimized: true,
  },
  // If deploying to a project-pages repo (username.github.io/repo-name),
  // uncomment and set these to your repo name:
  // basePath: "/echxion",
  // assetPrefix: "/echxion",
};

export default nextConfig;
