export const services = [
  {
    id: "smart-home",
    tag: "01",
    title: "Smart Home Automation",
    summary:
      "Connected living systems that respond to how a household actually moves through its day.",
    items: ["Lighting control", "Security & surveillance", "Smart locks", "Voice control", "Home monitoring"],
  },
  {
    id: "ai",
    tag: "02",
    title: "Artificial Intelligence",
    summary: "Applied AI that removes manual work from operations and sharpens decision-making.",
    items: ["Business process automation", "AI assistants", "Predictive analytics", "Machine learning solutions"],
  },
  {
    id: "electrical",
    tag: "03",
    title: "Electrical Engineering",
    summary: "Certified electrical work built to hold up under industrial and commercial load.",
    items: ["Electrical installations", "Maintenance & servicing", "Industrial systems", "Power distribution"],
  },
  {
    id: "solar",
    tag: "04",
    title: "Solar & Renewable Energy",
    summary: "Independent, resilient power — sized correctly and engineered to last.",
    items: ["Solar installation", "Battery storage", "Energy audits", "Hybrid systems"],
  },
  {
    id: "iot",
    tag: "05",
    title: "IoT Solutions",
    summary: "Sensor networks and connected devices that turn buildings into real-time data sources.",
    items: ["Connected devices", "Remote monitoring", "Industrial IoT", "Sensor networks"],
  },
  {
    id: "consultancy",
    tag: "06",
    title: "Engineering Consultancy",
    summary: "Independent technical advisory from planning through commissioning.",
    items: ["Project planning", "System design", "Feasibility studies", "Technical advisory"],
  },
] as const;

export const stats = [
  { value: 140, suffix: "+", label: "Projects completed" },
  { value: 98, suffix: "%", label: "Client satisfaction" },
  { value: 9, suffix: "+", label: "Years of experience" },
  { value: 32, suffix: "", label: "In-house engineers" },
  { value: 24, suffix: "/7", label: "Support response" },
] as const;

export const whyChoose = [
  {
    title: "Certified professionals",
    body: "Every engineer on site is licensed and trained to current international standards.",
  },
  {
    title: "Innovative solutions",
    body: "We design around outcomes first, then select the technology that gets you there.",
  },
  {
    title: "Energy-efficient designs",
    body: "Systems are specified to reduce consumption from day one, not retrofitted later.",
  },
  {
    title: "24/7 support",
    body: "A monitored response line covers every live installation, year-round.",
  },
  {
    title: "Industry best practices",
    body: "Documentation, testing, and commissioning follow IEC and NEC-aligned procedures.",
  },
  {
    title: "Reliable delivery",
    body: "Fixed milestones, transparent reporting, and contractors who show up on schedule.",
  },
  {
    title: "Client-centric approach",
    body: "One point of contact from first consultation through post-installation support.",
  },
] as const;

export type ProjectCategory =
  | "Residential"
  | "Commercial"
  | "Industrial"
  | "Solar"
  | "Automation"
  | "Electrical";

export const projectCategories: ProjectCategory[] = [
  "Residential",
  "Commercial",
  "Industrial",
  "Solar",
  "Automation",
  "Electrical",
];

export const projects: {
  id: string;
  title: string;
  category: ProjectCategory;
  client: string;
  location: string;
  services: string[];
  challenge: string;
  result: string;
}[] = [
  {
    id: "lekki-residence",
    title: "Lekki Smart Residence",
    category: "Residential",
    client: "Private homeowner",
    location: "Lekki, Lagos",
    services: ["Smart Home Automation", "Solar & Battery Storage"],
    challenge:
      "Unreliable grid power and a fully manual home with no centralized control across three floors.",
    result: "94% uptime on backup power and single-app control across lighting, security, and climate.",
  },
  {
    id: "victoria-tower",
    title: "Victoria Island Office Tower",
    category: "Commercial",
    client: "Regional real estate group",
    location: "Victoria Island, Lagos",
    services: ["Building Automation", "Energy Management"],
    challenge: "Rising energy costs across 14 floors with no visibility into consumption by tenant.",
    result: "31% reduction in shared energy costs within the first two quarters of operation.",
  },
  {
    id: "agro-processing",
    title: "Agro-Processing Plant Power Upgrade",
    category: "Industrial",
    client: "Food processing manufacturer",
    location: "Ogun State",
    services: ["Electrical Engineering", "Power Distribution"],
    challenge: "Frequent line trips were halting production during peak processing hours.",
    result: "Zero unplanned electrical downtime in the twelve months following commissioning.",
  },
  {
    id: "abuja-estate-solar",
    title: "Abuja Estate Solar Rollout",
    category: "Solar",
    client: "Residential estate developer",
    location: "Abuja, FCT",
    services: ["Solar Installation", "Hybrid Systems"],
    challenge: "48 units needed independent power without overloading the estate's shared infrastructure.",
    result: "Each unit now runs on a dedicated hybrid system with 60% lower grid dependence.",
  },
  {
    id: "retail-hq-ai",
    title: "Retail HQ Predictive Operations",
    category: "Automation",
    client: "National retail chain",
    location: "Ikeja, Lagos",
    services: ["AI Assistants", "Predictive Analytics"],
    challenge: "Manual demand forecasting was causing recurring stock imbalances across branches.",
    result: "Forecast accuracy improved by 42%, cutting emergency restock orders significantly.",
  },
  {
    id: "port-harcourt-substation",
    title: "Port Harcourt Substation Rewire",
    category: "Electrical",
    client: "Industrial estate operator",
    location: "Port Harcourt, Rivers State",
    services: ["Electrical Installations", "Maintenance"],
    challenge: "Aging distribution infrastructure was flagged as a safety risk during a routine audit.",
    result: "Full rewire completed with zero production downtime and a clean safety re-certification.",
  },
];

export const industries = [
  "Healthcare",
  "Real Estate",
  "Hospitality",
  "Manufacturing",
  "Education",
  "Government",
  "Retail",
  "Residential",
] as const;

export const testimonials = [
  {
    quote:
      "The team designed our building automation system around how our staff actually work, not a generic template. Energy costs dropped within the first billing cycle.",
    name: "Adaeze Okonkwo",
    role: "Facilities Director, Victoria Island Office Tower",
  },
  {
    quote:
      "We had three unplanned outages a month before ECHXION rebuilt our distribution setup. We haven't had one since commissioning.",
    name: "Tunde Bakare",
    role: "Plant Manager, Agro-Processing Plant",
  },
  {
    quote:
      "From feasibility study to final commissioning, communication never dropped. Every milestone landed on the date we agreed.",
    name: "Ngozi Umeh",
    role: "Development Lead, Abuja Estate Project",
  },
  {
    quote:
      "Our home finally feels like one system instead of a pile of separate gadgets. Support has answered within minutes every time we've called.",
    name: "Chidi Eze",
    role: "Homeowner, Lekki",
  },
] as const;

export const partners = [
  "Google Home",
  "Amazon Alexa",
  "Schneider Electric",
  "Siemens",
  "ABB",
  "Hikvision",
  "Dahua",
  "OpenAI",
  "Microsoft Azure",
  "AWS",
] as const;

export const blogPosts = [
  {
    title: "What Actually Determines Solar System Size for a Nigerian Home",
    category: "Renewable Energy",
    excerpt:
      "Load profile, roof orientation, and backup expectations matter more than panel count. Here's how we size a system before we quote one.",
    readTime: "6 min read",
  },
  {
    title: "Five Signs Your Building's Wiring Needs an Audit",
    category: "Electrical Safety",
    excerpt:
      "Warm outlets and flickering panels are late warnings, not early ones. What to check before they become a fire risk.",
    readTime: "5 min read",
  },
  {
    title: "Where AI Actually Saves Businesses Money in 2026",
    category: "AI Innovations",
    excerpt:
      "Forecasting and anomaly detection are outperforming flashier automation use cases in every project we've delivered this year.",
    readTime: "7 min read",
  },
  {
    title: "Smart Home Automation Without the Gadget Clutter",
    category: "Smart Home Tips",
    excerpt:
      "The best automated homes are the ones you stop noticing. A practical framework for choosing what to automate first.",
    readTime: "4 min read",
  },
  {
    title: "Building Automation Trends Worth Budgeting For",
    category: "Automation Trends",
    excerpt:
      "Occupancy-based HVAC and predictive maintenance are moving from luxury to standard spec on new commercial builds.",
    readTime: "6 min read",
  },
  {
    title: "Battery Storage 101: What a kWh Actually Buys You",
    category: "Renewable Energy",
    excerpt:
      "A plain-language breakdown of how to translate your appliance list into the battery capacity you actually need.",
    readTime: "5 min read",
  },
] as const;

export const faqs = [
  {
    q: "How long does a typical solar installation take?",
    a: "Residential systems are usually completed in 3–7 working days after design approval. Commercial and industrial installations depend on scale, typically 2–8 weeks, and we provide a firm schedule after the site survey.",
  },
  {
    q: "Do you offer maintenance after installation?",
    a: "Yes. Every project includes a commissioning warranty, and we offer ongoing maintenance plans with 24/7 monitored support for automation, electrical, and solar systems.",
  },
  {
    q: "Can you integrate with devices we already own?",
    a: "In most cases, yes. We assess your existing hardware during consultation and design around compatible ecosystems like Google Home and Amazon Alexa wherever possible, rather than replacing everything.",
  },
  {
    q: "Do you work outside Lagos and Abuja?",
    a: "Yes, we deliver projects across Nigeria and take on select engagements internationally. Site surveys and logistics are scoped during the initial consultation.",
  },
  {
    q: "What does the consultation process involve?",
    a: "A technical advisor reviews your goals and site conditions, followed by a feasibility assessment and a detailed proposal with cost and timeline before any work begins.",
  },
  {
    q: "How do you price projects?",
    a: "Pricing is scoped per project based on system size, materials, and complexity. We provide a transparent, itemized quote after the feasibility study — no flat packages that don't fit your site.",
  },
] as const;
