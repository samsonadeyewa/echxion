# ECHXION LTD — Website

Premium one-page marketing site for ECHXION LTD, built with Next.js (App
Router), TypeScript, Tailwind CSS v4, and Framer Motion.

## Stack

- Next.js 16 (App Router, static export)
- TypeScript
- Tailwind CSS v4
- Framer Motion (page-load and scroll animations)
- lucide-react (icons)

## Design tokens

| Role | Value |
|---|---|
| Navy (primary) | `#0B1F3A` |
| Navy deep (dark sections) | `#060F1E` |
| Electric blue (secondary) | `#007BFF` |
| Emerald (accent) | `#1DB954` |
| Display type | Space Grotesk |
| Heading/UI type | Manrope |
| Body type | Inter |

Fonts load via Google Fonts `<link>` tags in `app/layout.tsx` (not
`next/font/google`), so builds don't require network access to
`fonts.gstatic.com` at build time — useful if you ever build in a sandboxed
CI environment.

## Project structure

```
app/
  layout.tsx      – fonts, metadata
  page.tsx         – assembles all sections
  globals.css      – design tokens + Tailwind
components/
  Navbar, Hero, StatsStrip, About, Services, WhyChoose,
  Projects, Industries, Testimonials, Partners, Blog, FAQ,
  Contact, Footer
lib/
  data.ts          – all site content (services, projects, testimonials,
                      FAQ, blog posts, etc.) — edit this file to update copy
```

## Local development

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Building for production

```bash
npm run build
```

Because `next.config.ts` sets `output: "export"`, this produces a fully
static site in the `out/` folder — no Node server required.

## Deploying to GitHub Pages — automated (recommended for Acode)

This repo includes `.github/workflows/deploy.yml`, which builds and deploys
the site automatically on every push. This means you never have to run
`npm install` or `npm run build` yourself — Acode can't run Node anyway, so
this is the way to go if you're editing on your phone.

**One-time setup:**

1. Upload this whole folder to a GitHub repo (as normal, via the web
   interface, including the `.github` folder — make sure hidden folders
   aren't skipped when you drag files in).
2. In the repo: **Settings → Pages → Build and deployment → Source** → set
   this to **GitHub Actions** (not "Deploy from a branch").
3. If this repo is a **project page** (URL will be
   `username.github.io/repo-name`, not the bare `username.github.io`), open
   `next.config.ts` and uncomment:
   ```ts
   basePath: "/repo-name",
   assetPrefix: "/repo-name",
   ```
   replacing `repo-name` with your actual repo name, then push. Skip this
   step entirely if this repo *is* your root `username.github.io` repo.
4. Push to `main`. Check the **Actions** tab — you'll see a "Deploy to
   GitHub Pages" run. When it goes green, the site is live at the URL shown
   in the Pages settings.

**From then on:** edit files in Acode, commit, upload/push the changed
files through GitHub's web interface as usual. The workflow rebuilds and
redeploys automatically within a minute or two — no local build step.

## Deploying to GitHub Pages — manual (fallback)

1. Run `npm run build`. Static files land in `out/`.
2. If this repo is a **project page** (`username.github.io/echxion`, not the
   root `username.github.io`), open `next.config.ts` and uncomment:
   ```ts
   basePath: "/echxion",
   assetPrefix: "/echxion",
   ```
   Match `/echxion` to your actual repo name, then rebuild.
3. Upload the contents of `out/` to your `gh-pages` branch (or the branch
   your Pages settings point to) — the same way you've uploaded other
   builds via GitHub's web interface: drag the files from `out/` into the
   repo, or use GitHub Actions to automate `npm run build` on push.
4. Add an empty file named `.nojekyll` inside `out/` before uploading, so
   GitHub Pages doesn't ignore the `_next` folder (paths starting with `_`
   are ignored by Jekyll by default).

## Content you'll want to personalize before launch

- `lib/data.ts` — swap placeholder client names/results in `projects` and
  `testimonials` for real ones, and update `partners` if any listed
  technology relationships aren't accurate.
- `components/Contact.tsx` — real phone number, email, WhatsApp number, and
  Google Maps embed query (currently placeholder Victoria Island coordinates).
- `components/Footer.tsx` — real social links (currently `#`).
- Project images: `components/Projects.tsx` currently uses gradient tiles
  as placeholders per category — swap in real project photography by
  replacing the `<div className={gradient...}>` block with an `<img>` or
  Next `<Image>` once you have screenshots, same pattern as your portfolio
  site.
