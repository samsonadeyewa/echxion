import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import StatsStrip from "@/components/StatsStrip";
import About from "@/components/About";
import Services from "@/components/Services";
import WhyChoose from "@/components/WhyChoose";
import Projects from "@/components/Projects";
import Industries from "@/components/Industries";
import Testimonials from "@/components/Testimonials";
import Partners from "@/components/Partners";
import Blog from "@/components/Blog";
import FAQ from "@/components/FAQ";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <StatsStrip />
      <About />
      <Services />
      <WhyChoose />
      <Projects />
      <Industries />
      <Testimonials />
      <Partners />
      <Blog />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  );
}
