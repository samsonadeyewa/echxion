import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ECHXION LTD | Engineering Smarter Futures",
  description:
    "ECHXION LTD designs intelligent engineering solutions that combine AI, automation, electrical systems, and renewable energy to transform homes, businesses, and industries across Nigeria and beyond.",
  keywords: [
    "smart home automation Nigeria",
    "solar energy systems",
    "electrical engineering company",
    "IoT solutions Nigeria",
    "building automation",
    "renewable energy Nigeria",
    "ECHXION",
  ],
  openGraph: {
    title: "ECHXION LTD | Engineering Smarter Futures. Powering Intelligent Living.",
    description:
      "Intelligent infrastructure and sustainable energy solutions for homes, businesses, industries and government.",
    type: "website",
    locale: "en_NG",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Manrope:wght@500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased bg-white text-navy">{children}</body>
    </html>
  );
}
